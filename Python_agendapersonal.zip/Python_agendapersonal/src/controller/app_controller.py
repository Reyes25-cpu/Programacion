from __future__ import annotations
from datetime import datetime
from typing import Optional
from ..model.agenda import AgendaModel, Persona  # Para JSON
from ..view.app_view import Appview

class AgendaController:
    def __init__(self, model: AgendaModel, view: Appview) -> None:
        self.model = model
        self.view = view
        self._setup_handlers()
        
        # Mostrar cantidad de datos cargados
        cantidad = self.model.obtener_cantidad_personas()
        print(f"Agenda iniciada con {cantidad} personas cargadas")
    
    def _setup_handlers(self) -> None:
        self.view.btn_guardar.config(command=self.guardar_datos)
        self.view.buscar_ventana_callback = self._setup_buscar_handlers
    
    def _setup_buscar_handlers(self, buscar_window, btn_buscar, entry_documento, labels_resultado):
        btn_buscar.config(command=lambda: self.buscar_datos(entry_documento, labels_resultado))
        self.buscar_window = buscar_window
        self.labels_resultado = labels_resultado
    
    def guardar_datos(self) -> None:
        try:
            nombres = self.view.entry_Nombres.get().strip()
            apellidos = self.view.entry_Apellidos.get().strip()
            numero_documento = self.view.entry_Numerodocumento.get().strip()
            fecha_nacimiento = self.view.entry_FechaNacimiento.get_date()
            correo = self.view.entry_Correo.get().strip()
            direccion = self.view.entry_Direccion.get().strip()
            numero_hijos = int(self.view.hijos.get())
            cargo = self.view.entry_Cargo.get().strip()
            empresa = self.view.entry_Empresa.get().strip()
            
            if not all([nombres, apellidos, numero_documento, correo]):
                self.view.mostrar_error("Por favor complete todos los campos obligatorios")
                return
            
            persona = Persona(
                nombres=nombres,
                apellidos=apellidos,
                numero_documento=numero_documento,
                fecha_nacimiento=fecha_nacimiento,
                correo_electronico=correo,
                direccion_correspondencia=direccion,
                numero_hijos=numero_hijos,
                cargo=cargo,
                empresa=empresa
            )
            
            self.model.guardar_persona(persona)
            self.view.clear()
            self.view.mostrar_exito("Datos guardados correctamente")
            
        except ValueError as e:
            self.view.mostrar_error(f"Error en los datos: {str(e)}")
        except Exception as e:
            self.view.mostrar_error(f"Error al guardar: {str(e)}")
    
    def buscar_datos(self, entry_documento, labels_resultado) -> None:
        try:
            numero_documento = entry_documento.get().strip()
            
            if not numero_documento:
                self.view.mostrar_error("Ingrese un número de documento para buscar")
                return
            
            persona = self.model.buscar_por_documento(numero_documento)
            
            if persona:
                labels_resultado['nombres'].config(text=persona.nombres)
                labels_resultado['apellidos'].config(text=persona.apellidos)
                labels_resultado['documento'].config(text=persona.numero_documento)
                labels_resultado['fecha_nacimiento'].config(text=persona.fecha_nacimiento.strftime("%d/%m/%Y"))
                labels_resultado['correo'].config(text=persona.correo_electronico)
                labels_resultado['direccion'].config(text=persona.direccion_correspondencia)
                labels_resultado['hijos'].config(text=str(persona.numero_hijos))
                labels_resultado['cargo'].config(text=persona.cargo)
                labels_resultado['empresa'].config(text=persona.empresa)
            else:
                self.view.mostrar_error("No se encontró ninguna persona con ese documento")
                for label in labels_resultado.values():
                    label.config(text="")
                    
        except Exception as e:
            self.view.mostrar_error(f"Error al buscar: {str(e)}")