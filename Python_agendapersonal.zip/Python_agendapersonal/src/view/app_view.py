from __future__ import annotations

import tkinter as tk
from tkinter import messagebox
from typing import Tuple, Optional, Dict, Callable
from tkinter import ttk
from tkcalendar import DateEntry
from datetime import date

class Appview(tk.Tk):

    def __init__(self) -> None:
        super().__init__()

        # Ventana Principal
        self.title("Agenda Personal")
        self.resizable(False, False)
        self.iconbitmap("Minuto.ico")

        self.protocol("WM_DELETE_WINDOW", self.cerrar)

        self._controller = None
        self.buscar_ventana_callback = None

        frm = tk.Frame(self, padx=12, pady=12)
        frm.pack(fill=tk.BOTH, expand=True)

        # Validacion de letras
        def solo_letras(texto: str) -> bool:
            """Permite solo letras y espacios."""
            return all(c.isalpha() or c.isspace() for c in texto) or texto == ""
        
        # Validacion de numeros
        def solo_numeros(texto: str) -> bool:
            """Permite solo números."""
            return texto.isdigit() or texto == ""

        validar_letras = self.register(solo_letras)
        validar_numeros = self.register(solo_numeros)

        # Etiquetas
        tk.Label(frm, text="Nombres:", font=("Times New Roman", 15)).grid(row=0, column=0, ipady=5)
        tk.Label(frm, text="Apellidos:", font=("Times New Roman", 15)).grid(row=1, column=0, ipady=5)
        tk.Label(frm, text="Número documento:", font=("Times New Roman", 15)).grid(row=2, column=0, ipady=5)
        tk.Label(frm, text="Fecha de nacimiento:", font=("Times New Roman", 15)).grid(row=3, column=0,ipady=5)
        tk.Label(frm, text="Correo eléctronico:", font=("Times New Roman", 15)).grid(row=4, column=0,ipady=5)
        tk.Label(frm, text="Dirección correspondencia:", font=("Times New Roman", 15)).grid(row=5, column=0,ipady=5)
        tk.Label(frm, text="Número de hijos:", font=("Times New Roman", 15)).grid(row=6, column=0, ipady=5)
        tk.Label(frm, text="Cargo:", font=("Times New Roman", 15)).grid(row=7, column=0, ipady=5)
        tk.Label(frm, text="Empresa:", font=("Times New Roman", 15)).grid(row=8, column=0, ipady=5)

        self.entry_Nombres = tk.Entry(frm, width=25, validate="key", validatecommand=(validar_letras, "%P"))
        self.entry_Apellidos = tk.Entry(frm, width=25, validate="key", validatecommand=(validar_letras, "%P"))
        self.entry_Numerodocumento = tk.Entry(frm, width=25, validate="key", validatecommand=(validar_numeros, "%P"))
        self.entry_Correo = tk.Entry(frm, width=25)
        self.entry_Direccion = tk.Entry(frm, width=25)
        self.entry_Cargo = tk.Entry(frm, width=25, validate="key", validatecommand=(validar_letras, "%P"))
        self.entry_Empresa = tk.Entry(frm, width=25, validate="key", validatecommand=(validar_letras, "%P"))

        self.hijos = ttk.Combobox(frm, width=5, state="readonly", font=("Times New Roman", 12))
        self.hijos["values"] = [str(i) for i in range(0, 11)]
        self.hijos.current(0)
        self.hijos.grid(row=6, column=1, ipadx=3)

        # fecha de nacimiento
        self.entry_FechaNacimiento = DateEntry(frm, width=22, background="darkseagreen4", foreground="white", borderwidth=2, date_pattern="dd/mm/yyyy", font=("Times New Roman", 12), maxdate=date.today())
        self.entry_FechaNacimiento.set_date(date.today())
        self.entry_FechaNacimiento.grid(row=3, column=1, padx=6, pady=4, ipadx=5)

        # Ubicar los Entry
        self.entry_Nombres.grid(row=0, column=1, padx=6, pady=4, ipadx=5)
        self.entry_Apellidos.grid(row=1, column=1, padx=6, pady=4, ipadx=5)
        self.entry_Numerodocumento.grid(row=2, column=1, padx=6, pady=4, ipadx=5)
        self.entry_Correo.grid(row=4, column=1, padx=6, pady=4, ipadx=5)
        self.entry_Direccion.grid(row=5, column=1, padx=6, pady=4, ipadx=5)
        self.entry_Cargo.grid(row=7, column=1, padx=6, pady=4, ipadx=5)
        self.entry_Empresa.grid(row=8, column=1, padx=6, pady=4, ipadx=5)

        # Botones
        actions = tk.Frame(frm)
        actions.grid(row=20, column=0, columnspan=15, pady=6)

        self.btn_clear = tk.Button(actions, bg="darkseagreen4", text="Limpiar", font=("Times New Roman", 12), width=10, command=self.clear)
        self.btn_exit = tk.Button(actions, bg="darkseagreen4", text="Salir", font=("Times New Roman", 12), width=10, command=self.cerrar)
        self.btn_buscar = tk.Button(actions, bg="darkseagreen4", text="Buscar", font=("Times New Roman", 12), width=10, command=self.buscar_ventana)
        self.btn_guardar = tk.Button(actions, bg="darkseagreen4", text="Guardar Datos", font=("Times New Roman", 12), width=11)

        self.btn_clear.grid(row=0, column=2, padx=6)
        self.btn_exit.grid(row=0, column=3, padx=6)
        self.btn_buscar.grid(row=0, column=1, padx=6)
        self.btn_guardar.grid(row=0, column=0, padx=6)

    def buscar_ventana(self):
        # Ventana de busqueda
        self.buscar_window = tk.Toplevel()
        self.buscar_window.title("Ventana de búsqueda")
        self.buscar_window.resizable(False, False)
        self.buscar_window.iconbitmap("Minuto.ico")

        bsc = tk.Frame(self.buscar_window, padx=12, pady=12)
        bsc.pack(fill=tk.BOTH, expand=True)

        def solo_numeros(texto: str) -> bool:
            return texto.isdigit() or texto == ""

        validar_numeros = self.register(solo_numeros)

        tk.Label(bsc, text="Número de documento a buscar:", font=("Times New Roman", 15)).grid(row=0, column=0, sticky="w")
        
        # Etiquetas para mostrar resultados
        tk.Label(bsc, text="Nombres:", font=("Times New Roman", 15)).grid(row=2, column=0, sticky="w", ipady=5) 
        tk.Label(bsc, text="Apellidos:", font=("Times New Roman", 15)).grid(row=3, column=0, sticky="W", ipady=5) 
        tk.Label(bsc, text="Número documento:", font=("Times New Roman", 15)).grid(row=4, column=0, sticky="W", ipady=5) 
        tk.Label(bsc, text="Fecha de nacimiento:", font=("Times New Roman", 15)).grid(row=5, column=0, sticky="w", ipady=5) 
        tk.Label(bsc, text="Correo eléctronico:", font=("Times New Roman", 15)).grid(row=6, column=0, sticky="w", ipady=5) 
        tk.Label(bsc, text="Dirección correspondencia:", font=("Times New Roman", 15)).grid(row=7, column=0, sticky="w", ipady=5) 
        tk.Label(bsc, text="Número de hijos:", font=("Times New Roman", 15)).grid(row=8, column=0, sticky="w", ipady=5) 
        tk.Label(bsc, text="Cargo:", font=("Times New Roman", 15)).grid(row=9, column=0, sticky="w", ipady=5) 
        tk.Label(bsc, text="Empresa:", font=("Times New Roman", 15)).grid(row=10, column=0, sticky="w", ipady=5)

        self.entry_documento = tk.Entry(bsc, width=25, validate="key", validatecommand=(validar_numeros, "%P"))
        self.entry_documento.grid(row=0, column=1, padx=6, pady=4, ipadx=5)

        self.btn_buscar_window = tk.Button(bsc, bg="darkseagreen4", text="Buscar", font=("Times New Roman", 12), width=10)
        self.btn_buscar_window.grid(row=0, column=2, padx=6)

        # Labels para mostrar resultados
        labels_resultado = {
            'nombres': tk.Label(bsc, text="", font=("Times New Roman", 15)),
            'apellidos': tk.Label(bsc, text="", font=("Times New Roman", 15)),
            'documento': tk.Label(bsc, text="", font=("Times New Roman", 15)),
            'fecha_nacimiento': tk.Label(bsc, text="", font=("Times New Roman", 15)),
            'correo': tk.Label(bsc, text="", font=("Times New Roman", 15)),
            'direccion': tk.Label(bsc, text="", font=("Times New Roman", 15)),
            'hijos': tk.Label(bsc, text="", font=("Times New Roman", 15)),
            'cargo': tk.Label(bsc, text="", font=("Times New Roman", 15)),
            'empresa': tk.Label(bsc, text="", font=("Times New Roman", 15))
        }

        # Posicionar labels de resultados
        labels_resultado['nombres'].grid(row=2, column=1, sticky="w", ipady=5)
        labels_resultado['apellidos'].grid(row=3, column=1, sticky="w", ipady=5)
        labels_resultado['documento'].grid(row=4, column=1, sticky="w", ipady=5)
        labels_resultado['fecha_nacimiento'].grid(row=5, column=1, sticky="w", ipady=5)
        labels_resultado['correo'].grid(row=6, column=1, sticky="w", ipady=5)
        labels_resultado['direccion'].grid(row=7, column=1, sticky="w", ipady=5)
        labels_resultado['hijos'].grid(row=8, column=1, sticky="w", ipady=5)
        labels_resultado['cargo'].grid(row=9, column=1, sticky="w", ipady=5)
        labels_resultado['empresa'].grid(row=10, column=1, sticky="w", ipady=5)

        # Botones
        actions = tk.Frame(bsc)
        actions.grid(row=20, column=0, pady=6)

        self.btn_clear_window = tk.Button(actions, bg="darkseagreen4", text="Limpiar", font=("Times New Roman", 12), width=10, command=self.limpiar_ventana2)
        self.btn_exit_window = tk.Button(actions, bg="darkseagreen4", text="Cerrar", font=("Times New Roman", 12), width=10, command=self.buscar_window.destroy)
        self.btn_clear_window.grid(row=0, column=1, padx=6)
        self.btn_exit_window.grid(row=0, column=2, padx=6)

        # Llamar al callback para configurar los handlers
        if self.buscar_ventana_callback:
            self.buscar_ventana_callback(self.buscar_window, self.btn_buscar_window, self.entry_documento, labels_resultado)

    def cerrar(self):
        respuesta = messagebox.askquestion("Confirmar salida", "¿Seguro que quieres salir?")
        if respuesta == "yes":
            self.destroy()

    def clear(self) -> None:
        self.entry_Nombres.delete(0, tk.END)
        self.entry_Apellidos.delete(0, tk.END)
        self.entry_Numerodocumento.delete(0, tk.END)
        self.entry_Direccion.delete(0, tk.END)
        self.entry_Correo.delete(0, tk.END)
        self.entry_Cargo.delete(0, tk.END)
        self.entry_Empresa.delete(0, tk.END)
        self.hijos.current(0)
        self.entry_FechaNacimiento.set_date(date.today())

    def limpiar_ventana2(self) -> None:
        self.entry_documento.delete(0, tk.END)

    def mostrar_error(self, mensaje: str) -> None:
        messagebox.showerror("Error", mensaje)

    def mostrar_exito(self, mensaje: str) -> None:
        messagebox.showinfo("Éxito", mensaje)

    def set_controller(self, controller) -> None:
        self._controller = controller