from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import date, datetime
from typing import List, Optional
import json
import os

@dataclass
class Persona:
    nombres: str
    apellidos: str
    numero_documento: str
    fecha_nacimiento: date
    correo_electronico: str
    direccion_correspondencia: str
    numero_hijos: int
    cargo: str
    empresa: str
    
    def to_dict(self) -> dict:
        """Convierte la persona a diccionario para JSON"""
        return {
            'nombres': self.nombres,
            'apellidos': self.apellidos,
            'numero_documento': self.numero_documento,
            'fecha_nacimiento': self.fecha_nacimiento.isoformat(),
            'correo_electronico': self.correo_electronico,
            'direccion_correspondencia': self.direccion_correspondencia,
            'numero_hijos': self.numero_hijos,
            'cargo': self.cargo,
            'empresa': self.empresa
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> Persona:
        """Crea una Persona desde un diccionario"""
        return cls(
            nombres=data['nombres'],
            apellidos=data['apellidos'],
            numero_documento=data['numero_documento'],
            fecha_nacimiento=datetime.fromisoformat(data['fecha_nacimiento']).date(),
            correo_electronico=data['correo_electronico'],
            direccion_correspondencia=data['direccion_correspondencia'],
            numero_hijos=data['numero_hijos'],
            cargo=data['cargo'],
            empresa=data['empresa']
        )

class AgendaModel:
    def __init__(self, archivo_datos: str = "datos_agenda.json") -> None:
        self._archivo_datos = archivo_datos
        self._personas: List[Persona] = []
        self._cargar_datos()
    
    def _cargar_datos(self) -> None:
        """Carga los datos desde el archivo JSON"""
        try:
            if os.path.exists(self._archivo_datos):
                with open(self._archivo_datos, 'r', encoding='utf-8') as archivo:
                    datos = json.load(archivo)
                    self._personas = [Persona.from_dict(item) for item in datos]
                print(f"Datos cargados: {len(self._personas)} personas")
            else:
                print("No existe archivo de datos, se creará uno nuevo")
        except Exception as e:
            print(f"Error al cargar datos: {e}")
            self._personas = []
    
    def _guardar_datos(self) -> None:
        """Guarda los datos en el archivo JSON"""
        try:
            datos = [persona.to_dict() for persona in self._personas]
            with open(self._archivo_datos, 'w', encoding='utf-8') as archivo:
                json.dump(datos, archivo, indent=2, ensure_ascii=False)
            print(f"Datos guardados: {len(self._personas)} personas")
        except Exception as e:
            print(f"Error al guardar datos: {e}")
    
    def guardar_persona(self, persona: Persona) -> None:
        """Guarda una nueva persona en la agenda"""
        # Verificar si ya existe una persona con el mismo documento
        persona_existente = self.buscar_por_documento(persona.numero_documento)
        if persona_existente:
            # Actualizar la persona existente
            index = self._personas.index(persona_existente)
            self._personas[index] = persona
        else:
            # Agregar nueva persona
            self._personas.append(persona)
        
        self._guardar_datos()
    
    def buscar_por_documento(self, numero_documento: str) -> Optional[Persona]:
        """Busca una persona por número de documento"""
        for persona in self._personas:
            if persona.numero_documento == numero_documento:
                return persona
        return None
    
    def eliminar_por_documento(self, numero_documento: str) -> bool:
        """Elimina una persona por número de documento"""
        persona = self.buscar_por_documento(numero_documento)
        if persona:
            self._personas.remove(persona)
            self._guardar_datos()
            return True
        return False
    
    def obtener_todas_personas(self) -> List[Persona]:
        """Retorna todas las personas guardadas"""
        return self._personas.copy()
    
    def obtener_cantidad_personas(self) -> int:
        """Retorna la cantidad de personas guardadas"""
        return len(self._personas)