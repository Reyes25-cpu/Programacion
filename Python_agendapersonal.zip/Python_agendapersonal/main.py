from __future__ import annotations
from src.view.app_view import Appview
from src.model.agenda import AgendaModel, Persona  # Para JSON
from src.controller.app_controller import AgendaController

class Main:
    def __init__(self) -> None:
        # Para JSON
        self.model = AgendaModel("datos_agenda.json")
        self.view = Appview()
        self.controller = AgendaController(self.model, self.view)

    def run(self) -> None:
        self.view.mainloop()

if __name__ == "__main__":
    Main().run()